// Author: Nuno Aguiar
// License: Apache 2.0
// Description: Shared utility functions used across mini-a components.

/**
 * Returns a formatted error message string from an error value.
 * Replaces the repeated `(e.message || String(e))` / `(isDef(e) && isString(e.message)) ? e.message : e` pattern.
 */
function __miniAErrMsg(e) {
  return (isDef(e) && isString(e.message)) ? e.message : String(e)
}

/**
 * Normalizes console event text while preserving message line boundaries.
 * Providers can supply either actual line feeds or escaped `\\n` sequences.
 */
function __miniANormalizeConsoleEventText(value) {
  return (isString(value) ? value : String(value || ""))
    .replace(/\r\n?/g, "\n")
    .replace(/\\n/g, "\n")
    .trim()
}

/**
 * Buffers a Markdown stream until it has complete renderable units. Markdown
 * renderers are line-oriented, so handing them provider-sized token fragments
 * loses inline formatting such as emphasis and links.
 */
function __miniAMarkdownStream(opts) {
  opts = isObject(opts) ? opts : {}
  var pending = "", inCode = false, code = "", codeFence = "", codeFenceLength = 0, chartCode = false, inTable = false, table = "", header = ""
  var separator = /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/

  function cellCount(line) {
    var value = String(line || "").trim()
    if (value.charAt(0) === "|") value = value.substring(1)
    if (value.charAt(value.length - 1) === "|") value = value.substring(0, value.length - 1)
    return value.length === 0 ? 0 : value.split("|").length
  }
  function isSeparator(line) { return separator.test(String(line || "").trim()) }
  function isRow(line) {
    var value = String(line || "").trim()
    if (value.length === 0 || isSeparator(value)) return false
    var pipes = (value.match(/\|/g) || []).length
    return (value.charAt(0) === "|" || pipes >= 2) && cellCount(value) >= 2
  }
  function emit(text, kind) {
    if (text.length > 0 && isFunction(opts.onUnit)) opts.onUnit(text, kind)
  }
  function preview() {
    if (isFunction(opts.onPreview)) opts.onPreview(opts.useasciiviz === true && (chartCode || /^ {0,3}(?:`{1,}|~{1,})/.test(pending)) ? "" : pending)
  }
  function process(line) {
    var withNl = line + "\n"
    if (inCode) {
      code += withNl
      var closing = line.match(/^ {0,3}(`{3,}|~{3,})[ \t]*$/)
      if (closing && closing[1].charAt(0) === codeFence && closing[1].length >= codeFenceLength) {
        emit(code, "code"); code = ""; inCode = false; chartCode = false
      }
      return
    }
    var opening = line.match(/^ {0,3}(`{3,}|~{3,})(.*)$/)
    if (opening) {
      if (inTable) { emit(table, "table"); table = ""; inTable = false }
      if (header.length > 0) { emit(header, "line"); header = "" }
      inCode = true; code = withNl; codeFence = opening[1].charAt(0); codeFenceLength = opening[1].length; chartCode = opening[2].trim() === "oafPrintChart"; return
    }
    if (inTable) {
      if (isRow(line) && cellCount(line) === cellCount(table.split("\n")[0])) { table += withNl; return }
      emit(table, "table"); table = ""; inTable = false
    }
    if (header.length > 0) {
      if (isSeparator(line) && cellCount(line) === cellCount(header)) {
        inTable = true; table = header + withNl; header = ""; return
      }
      emit(header, "line"); header = ""
    }
    if (isRow(line)) header = withNl
    else emit(withNl, "line")
  }
  return {
    feed: function(text) {
      pending += isDef(text) ? String(text) : ""
      var idx
      while ((idx = pending.indexOf("\n")) >= 0) {
        var line = pending.substring(0, idx)
        pending = pending.substring(idx + 1)
        process(line)
      }
      preview()
    },
    end: function() {
      if (pending.length > 0) {
        if (inCode) code += pending
        else if (inTable) table += pending
        else if (header.length > 0) { emit(header, "line"); header = ""; emit(pending, "line") }
        else emit(pending, "line")
      }
      pending = ""
      if (code.length > 0) emit(code, "code")
      if (table.length > 0) emit(table, "table")
      if (header.length > 0) emit(header, "line")
      inCode = false; code = ""; chartCode = false; inTable = false; table = ""; header = ""
      preview()
    },
    reset: function() { pending = ""; inCode = false; code = ""; chartCode = false; inTable = false; table = ""; header = ""; preview() }
  }
}

function __miniAHasConsoleChartFence(text) {
  return isString(text) && /^ {0,3}(?:`{3,}|~{3,})oafPrintChart[ \t]*\r?$/m.test(text)
}

/** Extract only complete chart fences, keeping nested code examples literal. */
function __miniAPreprocessConsoleCharts(text, opts) {
  var lines = String(text).split(/\r?\n/), output = [], charts = []
  var fence = "", fenceLength = 0, block = [], language = ""
  function finish(complete) {
    var original = block.join("\n")
    if (complete && language === "oafPrintChart") {
      try {
        var params = JSON.parse(block.slice(1, -1).join("\n"))
        if (!isMap(params)) throw "Chart parameters must be an object"
        params.options = isMap(params.options) ? params.options : {}
        if (isUnDef(params.options.width)) params.options.width = opts.width
        var chart = opts.renderChart(params)
        if (!isString(chart) || chart.indexOf("[ERROR]") === 0) throw chart
        if (opts.ansi !== true) chart = chart.replace(/\x1b\[[0-9;]*m/g, "")
        var marker = "MINIACHARTPLACEHOLDER" + charts.length + "END"
        while (String(text).indexOf(marker) >= 0) marker += "X"
        charts.push({ marker: marker, text: chart })
        output.push(marker)
      } catch(e) { output.push(original) }
    } else output.push(original)
    block = []; fence = ""; language = ""
  }
  lines.forEach(function(line) {
    if (fence.length > 0) {
      block.push(line)
      var close = line.match(/^ {0,3}(`{3,}|~{3,})[ \t]*$/)
      if (close && close[1].charAt(0) === fence && close[1].length >= fenceLength) finish(true)
    } else {
      var open = line.match(/^ {0,3}(`{3,}|~{3,})(.*)$/)
      if (open) {
        fence = open[1].charAt(0); fenceLength = open[1].length
        language = open[2].trim(); block = [line]
      } else output.push(line)
    }
  })
  if (block.length > 0) finish(false)
  return { text: output.join("\n"), charts: charts }
}

/** Render a complete Markdown unit without losing literal tags or list wraps. */
function __miniAMarkdownRender(text, width, opts) {
  var value = isDef(text) ? String(text) : ""
  opts = isObject(opts) ? opts : {}
  var ansi = isDef(opts.ansi) ? opts.ansi === true : (typeof __conAnsi !== "undefined" && __conAnsi === true)
  var prepared = { text: value, charts: [] }
  if (opts.useasciiviz === true && isFunction(opts.renderChart)) {
    prepared = __miniAPreprocessConsoleCharts(value, { width: width, ansi: ansi, renderChart: opts.renderChart })
    value = prepared.text
  }
  function restore(rendered) {
    prepared.charts.forEach(function(chart) { rendered = rendered.split(chart.marker).join(chart.text) })
    return rendered
  }
  if (ansi !== true || value.length === 0) return restore(value)
  if (opts.kind !== "code" && opts.kind !== "table") value = value.replace(/^( {0,3})[-+]\s+/gm, "$1* ")
  if (/<\?xml\b/i.test(value) || /^\s*<\/?[A-Za-z_][A-Za-z0-9_.:-]*(?:\s+[^<>]*?)?>\s*$/m.test(value)) return restore(value)
  // OpenAF's second withMD argument is an ANSI style, not a render width.
  // Passing a number here throws "defaultAnsi is not a string" mid-stream.
  if (!isObject(__flags) || !isObject(__flags.WITHMD)) return restore(ow.format.withMD(value))
  var oldHtmlFilter = __flags.WITHMD.htmlFilter
  try {
    __flags.WITHMD.htmlFilter = false
    return restore(ow.format.withMD(value))
  } finally {
    __flags.WITHMD.htmlFilter = oldHtmlFilter
  }
}

function __miniAMarkdownPreviewRows(text, width) {
  var wrapped = ow.format.string.wordWrap(String(text || ""), width)
  return String(wrapped || "").replace(/\r/g, "").split("\n").length
}

/**
 * Normalizes `askChoose` results into a safe zero-based index.
 * Returns -1 for blank, invalid, negative, or out-of-range values.
 *
 * @param {number|string} value - Raw choice index to normalize.
 * @param {number} [maxExclusive] - Optional exclusive upper bound.
 */
function __miniANormalizeChoiceIndex(value, maxExclusive) {
  var idx = isNumber(value) ? value : Number(value)
  if (isNaN(idx)) return -1
  idx = Math.floor(idx)
  if (idx < 0) return -1
  if (isNumber(maxExclusive) && idx >= maxExclusive) return -1
  return idx
}

/**
 * Resolves the canonical path to a SKILL.md template within a folder.
 * Returns the path string if found, or undefined if not found.
 *
 * @param {string} folderPath - The folder to look inside.
 * @param {string[]} [candidates] - Filenames to try (default: ["SKILL.md", "skill.md"]).
 */
function __miniAResolveSkillTemplateFromFolder(folderPath, candidates) {
  candidates = candidates || ["SKILL.yaml", "SKILL.yml", "SKILL.json", "SKILL.md", "skill.md"]
  if (!isString(folderPath) || folderPath.trim().length === 0) return __
  for (var i = 0; i < candidates.length; i++) {
    try {
      var candidatePath = String(new java.io.File(folderPath, candidates[i]).getCanonicalPath())
      if (!io.fileExists(candidatePath)) continue
      var info = io.fileInfo(candidatePath)
      if (isDef(info) && info.isFile === true) return candidatePath
    } catch (e) {}
  }
  return __
}

function __miniASkillTemplateFormatFromPath(templatePath) {
  if (!isString(templatePath)) return "markdown"
  var lower = templatePath.toLowerCase()
  if (/\.ya?ml$/i.test(lower)) return "yaml"
  if (/\.json$/i.test(lower)) return "json"
  return "markdown"
}

function __miniAShouldIgnoreSkillEntryName(entryName, includeHidden) {
  if (!isString(entryName) || entryName.length === 0) return true
  if (String(entryName).toLowerCase().endsWith(".disabled")) return true
  if (includeHidden !== true && entryName.indexOf(".") === 0) return true
  return false
}

function __miniAExtractFrontMatterMeta(markdownText) {
  var meta = __
  var body = isString(markdownText) ? String(markdownText) : String(markdownText || "")
  var normalized = body.replace(/^\uFEFF/, "").replace(/\r\n/g, "\n")
  var frontMatterMatch = normalized.match(/^---[ \t]*\n([\s\S]*?)\n---[ \t]*(?:\n|$)/)
  if (frontMatterMatch && isString(frontMatterMatch[1])) {
    try {
      var parsed = af.fromYAML(frontMatterMatch[1])
      if (isObject(parsed)) meta = parsed
    } catch (ignoreMetaParseError) {}
    body = normalized.substring(frontMatterMatch[0].length)
  } else {
    body = normalized
  }
  return {
    meta: isObject(meta) ? meta : __,
    body: body
  }
}

function __miniASerializeFrontMatter(meta, body) {
  var yaml = ""
  try { yaml = af.toYAML(isObject(meta) ? meta : {}) } catch(ignoreSerializeErr) { yaml = "" }
  return "---\n" + yaml + "---\n" + (isString(body) ? body : "")
}

function __miniASanitizeVirtualSkillPath(pathValue) {
  if (!isString(pathValue)) return __
  var normalized = pathValue.trim().replace(/\\/g, "/")
  if (normalized.length === 0) return __
  if (normalized.charAt(0) === "/") return __
  if (/^[A-Za-z]:\//.test(normalized)) return __
  if (/^[a-z][a-z0-9+.-]*:/i.test(normalized)) return __
  if (normalized.indexOf("..") >= 0) return __
  while (normalized.indexOf("//") >= 0) normalized = normalized.replace(/\/\//g, "/")
  if (normalized.length === 0 || normalized === ".") return __
  if (normalized.indexOf("./") === 0) normalized = normalized.substring(2)
  return normalized.length > 0 ? normalized : __
}

function __miniANormalizeSkillVirtualFiles(skillDoc) {
  var files = {}

  function joinPath(basePath, childPath) {
    if (!isString(childPath)) return __
    var sanitizedChild = __miniASanitizeVirtualSkillPath(childPath)
    if (!isString(sanitizedChild)) return __
    if (!isString(basePath) || basePath.length === 0) return sanitizedChild
    var merged = basePath + "/" + sanitizedChild
    return __miniASanitizeVirtualSkillPath(merged)
  }

  function appendFile(pathKey, value) {
    var normalizedPath = __miniASanitizeVirtualSkillPath(pathKey)
    if (!isString(normalizedPath)) return
    if (isUnDef(value) || value === null) {
      files[normalizedPath] = ""
      return
    }
    if (isString(value) || value instanceof java.lang.String) {
      files[normalizedPath] = String(value)
      return
    }
    if (isObject(value)) {
      if (isString(value.body)) {
        files[normalizedPath] = value.body
        return
      }
      if (isString(value.content)) {
        files[normalizedPath] = value.content
        return
      }
      if (isString(value.text)) {
        files[normalizedPath] = value.text
        return
      }
      files[normalizedPath] = ""
      return
    }
    files[normalizedPath] = String(value)
  }

  function visitRefs(refsMap, basePath) {
    if (!isObject(refsMap)) return
    Object.keys(refsMap).forEach(function(rawKey) {
      var refValue = refsMap[rawKey]
      var key = isString(rawKey) ? rawKey : String(rawKey)
      var joined = joinPath(basePath, key)
      if (!isString(joined)) return
      if (isObject(refValue) && isObject(refValue.refs)) {
        visitRefs(refValue.refs, joined)
        if (isString(refValue.body) || isString(refValue.content) || isString(refValue.text)) appendFile(joined, refValue)
        return
      }
      appendFile(joined, refValue)
    })
  }

  function visitChildren(children, basePath) {
    if (!isArray(children)) return
    children.forEach(function(child) {
      if (!isObject(child)) return
      var childPath = isString(child.path) ? child.path : ""
      var childBase = basePath
      if (childPath.length > 0) {
        childBase = joinPath(basePath, childPath)
        if (!isString(childBase)) childBase = basePath
      }
      if (isObject(child.refs)) visitRefs(child.refs, childBase)
      if (isArray(child.children)) visitChildren(child.children, childBase)
    })
  }

  if (isObject(skillDoc)) {
    if (isObject(skillDoc.refs)) visitRefs(skillDoc.refs, "")
    if (isArray(skillDoc.children)) visitChildren(skillDoc.children, "")
  }
  return files
}

function __miniALoadSkillTemplateDocument(templatePath) {
  if (!isString(templatePath) || templatePath.trim().length === 0) return __
  if (!io.fileExists(templatePath) || io.fileInfo(templatePath).isFile !== true) return __
  var raw = io.readFileString(templatePath)
  if (!isString(raw)) raw = String(raw || "")
  var format = __miniASkillTemplateFormatFromPath(templatePath)

  if (format === "markdown") {
    var md = __miniAExtractFrontMatterMeta(raw)
    var mdMeta = isObject(md.meta) ? md.meta : {}
    var mdDescription = isString(mdMeta.description) ? mdMeta.description.replace(/\s+/g, " ").trim() : ""
    return {
      format      : "markdown",
      rawContent  : raw,
      bodyTemplate: isString(md.body) ? md.body : "",
      description : mdDescription.length > 0 ? mdDescription : __,
      meta        : mdMeta,
      virtualFiles: {}
    }
  }

  var parsed
  try {
    parsed = format === "json" ? jsonParse(raw) : af.fromYAML(raw)
  } catch (parseError) {
    parsed = __
  }
  if (!isObject(parsed)) return __
  var bodyTemplate = ""
  if (isString(parsed.body)) bodyTemplate = parsed.body
  if (bodyTemplate.length === 0 && isString(parsed.goal)) bodyTemplate = parsed.goal
  var description = ""
  if (isString(parsed.summary)) description = parsed.summary
  if (description.length === 0 && isString(parsed.description)) description = parsed.description
  if (description.length === 0 && isObject(parsed.meta) && isString(parsed.meta.description)) description = parsed.meta.description
  description = isString(description) ? description.replace(/\s+/g, " ").trim() : ""

  return {
    format      : format,
    rawContent  : raw,
    bodyTemplate: bodyTemplate,
    description : description.length > 0 ? description : __,
    meta        : isObject(parsed.meta) ? parsed.meta : {},
    skillData   : parsed,
    virtualFiles: __miniANormalizeSkillVirtualFiles(parsed)
  }
}

/**
 * Reads a skill description from the YAML front-matter of a SKILL.md template.
 * Returns the description string, or undefined if not present / on error.
 *
 * @param {string} templatePath - Absolute path to the template file.
 */
function __miniAReadSkillDescriptionFromTemplate(templatePath) {
  if (!isString(templatePath) || templatePath.trim().length === 0) return __
  try {
    var loaded = __miniALoadSkillTemplateDocument(String(templatePath))
    if (!isObject(loaded) || !isString(loaded.description)) return __
    var description = loaded.description.replace(/\s+/g, " ").trim()
    return description.length > 0 ? description : __
  } catch (e) {
    return __
  }
}

function __miniAApplyMemoryUserDefaults(cfg) {
  if (!isObject(cfg)) return cfg

  cfg.memoryuser = toBoolean(cfg.memoryuser) === true
  cfg.memoryusersession = toBoolean(cfg.memoryusersession) === true
  if (cfg.memoryuser !== true && cfg.memoryusersession !== true) return cfg

  var _memUserHome = isDef(__gHDir) ? __gHDir() : java.lang.System.getProperty("user.home")
  var _memUserDir  = _memUserHome + "/.openaf-mini-a"
  var _memUserMemDir = _memUserDir + "/memory"
  io.mkdir(_memUserMemDir)

  if (cfg.memoryuser === true && isUnDef(cfg.memorych)) {
    cfg.memorych = stringify({ name: "mini_a_global_mem", type: "file", options: { file: _memUserMemDir + "/memory-global.json.gz", lock: _memUserMemDir + "/memory-global.lock", multifile: false, gzip: true, compact: true } }, __, "")
  }
  if (isUnDef(cfg.memorysessionch)) {
    cfg.memorysessionch = stringify({ name: "mini_a_session_mem", type: "file", options: { file: _memUserMemDir + "/memory-session.json.gz", lock: _memUserMemDir + "/memory-session.lock", multifile: false, gzip: true, compact: true } }, __, "")
  }
  if (cfg.memoryusersession === true && isUnDef(cfg.memoryscope) && isUnDef(cfg.memoryScope)) cfg.memoryscope = "session"
  cfg.usememory = true
  if (cfg.memoryuser === true) {
    if (isUnDef(cfg.memorypromote)) cfg.memorypromote = "facts,decisions,summaries"
    if (isUnDef(cfg.memorystaledays)) cfg.memorystaledays = 30
  }
  return cfg
}

/**
 * Removes leading YAML front-matter from markdown content when present.
 * Intended for slash command / skill template processing, so metadata blocks
 * used for listing do not leak into rendered prompts.
 *
 * @param {string} markdownText - Raw markdown text.
 * @returns {string} markdown without the leading front-matter block.
 */
function __miniAStripMarkdownFrontMatter(markdownText) {
  if (!isString(markdownText) || markdownText.length === 0) return ""
  var normalized = String(markdownText).replace(/^\uFEFF/, "").replace(/\r\n/g, "\n")
  var frontMatterMatch = normalized.match(/^---[ \t]*\n[\s\S]*?\n---[ \t]*(?:\n|$)/)
  if (!frontMatterMatch) return normalized
  return normalized.substring(frontMatterMatch[0].length)
}

/**
 * Renders a skill template by substituting {{args}}, {{argv}}, {{argc}},
 * and positional {{arg1}}…{{argN}} placeholders.
 * If the template contains no placeholders but arguments were provided,
 * arguments are auto-appended.
 *
 * @param {string}  template   - The raw template text.
 * @param {object}  parsedArgs - Object with `raw` (string), `argv` (array), `argc` (number).
 */
function __miniARenderSkillTemplate(template, parsedArgs) {
  var rendered = isString(template) ? template : String(template || "")
  var replacedAny = false
  var args = isObject(parsedArgs) ? parsedArgs : { raw: "", argv: [], argc: 0 }

  function replaceAll(placeholder, value) {
    if (rendered.indexOf(placeholder) >= 0) {
      replacedAny = true
      rendered = rendered.split(placeholder).join(value)
    }
  }

  var argvString = "[]"
  try {
    argvString = stringify(args.argv || [], __, "")
  } catch (e) {
    argvString = "[]"
  }

  replaceAll("{{args}}", args.raw || "")
  replaceAll("{{argv}}", argvString)
  replaceAll("{{argc}}", String(isNumber(args.argc) ? args.argc : 0))

  rendered = rendered.replace(/\{\{arg([1-9][0-9]*)\}\}/g, function(_, indexStr) {
    replacedAny = true
    var idx = Number(indexStr) - 1
    if (!isNaN(idx) && idx >= 0 && isArray(args.argv) && idx < args.argv.length) return args.argv[idx]
    return ""
  })

  if ((args.argc || 0) > 0 && replacedAny !== true) {
    rendered += "\n\nArguments (auto-appended):\n"
    rendered += "- raw: " + (args.raw || "") + "\n"
    rendered += "- argv: " + argvString + "\n"
    rendered += "- argc: " + (args.argc || 0) + "\n"
  }

  return rendered
}

/**
 * Builds a compact tool manifest array for /list-tools responses.
 * When proxyState is provided (mcpproxy=true), reads from the proxy connection catalog
 * so the listing is proxy-aware (includes connection alias).
 * Without proxyState, falls back to the plain tools array.
 *
 * @param {Array}   tools      - agent.mcpTools array (fallback when no proxy state)
 * @param {Object}  [proxyState] - global.__mcpProxyState__ when mcpproxy=true
 * @param {boolean} [withSchema] - if true, include inputSchema per tool
 * @returns {Array} compact tool entries: { name, description[, connection][, inputSchema] }
 */
function __miniABuildCompactToolManifest(tools, proxyState, withSchema) {
  withSchema = withSchema === true
  var result = []

  if (isObject(proxyState) && isObject(proxyState.connections)) {
    Object.keys(proxyState.connections).forEach(function(connId) {
      var conn = proxyState.connections[connId]
      if (!isObject(conn) || !isArray(conn.tools)) return
      var alias = isString(conn.alias) ? conn.alias : connId
      conn.tools.forEach(function(tool) {
        if (!isObject(tool) || !isString(tool.name)) return
        if (tool.name === "proxy-dispatch") return
        var desc = isString(tool.description) ? tool.description : ""
        var entry = {
          name       : tool.name,
          description: desc.split("\n")[0].trim(),
          connection : alias
        }
        if (withSchema && isObject(tool.inputSchema)) entry.inputSchema = tool.inputSchema
        result.push(entry)
      })
    })
  } else if (isArray(tools)) {
    tools.forEach(function(tool) {
      if (!isObject(tool) || !isString(tool.name)) return
      var desc = isString(tool.description) ? tool.description : ""
      var entry = {
        name       : tool.name,
        description: desc.split("\n")[0].trim()
      }
      if (withSchema && isObject(tool.inputSchema)) entry.inputSchema = tool.inputSchema
      result.push(entry)
    })
  }

  return result
}

/**
 * Loads additional libraries from a comma-separated string.
 * Supports both plain file paths and @oPack/library.js notation.
 *
 * @param {string}   libsString - Comma-separated list of library paths.
 * @param {function} [logFn]    - Called with informational messages (default: log).
 * @param {function} [errFn]    - Called with error messages (default: logErr).
 */
function __miniALoadLibraries(libsString, logFn, errFn) {
  if (!isString(libsString) || libsString.trim().length === 0) return
  logFn = isFunction(logFn) ? logFn : function(msg) { log(msg) }
  errFn = isFunction(errFn) ? errFn : function(msg) { logErr(msg) }
  libsString.split(",").map(function(r) { return r.trim() }).filter(function(r) { return r.length > 0 }).forEach(function(lib) {
    logFn("Loading library: " + lib + "...")
    try {
      if (lib.startsWith("@")) {
        if (/^\@([^\/]+)\/(.+)\.js$/.test(lib)) {
          var _ar = lib.match(/^\@([^\/]+)\/(.+)\.js$/)
          var _path = getOPackPath(_ar[1])
          var _file = _path + "/" + _ar[2] + ".js"
          if (io.fileExists(_file)) {
            loadLib(_file)
          } else {
            errFn("Library '" + lib + "' not found.")
          }
        } else {
          errFn("Library '" + lib + "' does not have the correct format (@oPack/library.js).")
        }
      } else {
        loadLib(lib)
      }
    } catch(e) {
      errFn("Failed to load library " + lib + ": " + __miniAErrMsg(e))
    }
  })
}

function __miniACleanCodeBlocks(text) {
  if (!isString(text)) return text
  var trimmed = String(text).trim()
  var isVisualBlock = trimmed.startsWith("```chart") || trimmed.startsWith("```mermaid") || trimmed.startsWith("```leaflet") || __miniAHasConsoleChartFence(trimmed)
  if (trimmed.startsWith("```") && trimmed.endsWith("```") && !isVisualBlock) {
    return trimmed.replace(/^```+[\w]*\n/, "").replace(/```+$/, "").trim()
  }
  return text
}

function __miniARepairJsonString(jsonString) {
  if (!isString(jsonString)) return jsonString

  // Repair punctuation only outside strings: answer text and tool arguments
  // may themselves contain snippets such as ",}" or "{key:value}".
  var parts = []
  var inString = false
  var escaped = false
  for (var i = 0; i < jsonString.length; i++) {
    var ch = jsonString.charAt(i)
    if (inString) {
      parts.push(ch)
      if (escaped) escaped = false
      else if (ch === "\\") escaped = true
      else if (ch === '"') inString = false
      continue
    }
    if (ch === '"') { inString = true; parts.push(ch); continue }
    if (ch === "," && /^\s*[}\]]/.test(jsonString.substring(i + 1))) continue
    parts.push(ch)
    if (ch === "{" || ch === ",") {
      var key = jsonString.substring(i + 1).match(/^(\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)(\s*:)/)
      if (key) {
        parts.push(key[1] + '"' + key[2] + '"' + key[3])
        i += key[0].length
      }
    }
  }
  var repaired = parts.join("")

  var parsed = jsonParse(repaired, __, __, true)
  if (isMap(parsed) || isArray(parsed)) return repaired

  var _fixed = (function(s) {
    var out = []
    var inStr = false
    var esc = false
    for (var _i = 0; _i < s.length; _i++) {
      var ch = s[_i]
      if (esc) { out.push(ch); esc = false; continue }
      if (ch === "\\") { out.push(ch); esc = true; continue }
      if (ch === '"') {
        if (!inStr) {
          inStr = true; out.push(ch)
        } else {
          var pk = _i + 1
          while (pk < s.length && (s[pk] === " " || s[pk] === "\t")) pk++
          var nc = pk < s.length ? s[pk] : ""
          if (nc === "" || nc === "," || nc === "}" || nc === "]" || nc === ":" || nc === "\n" || nc === "\r") {
            inStr = false; out.push(ch)
          } else {
            out.push("\\"); out.push('"')
          }
        }
      } else {
        out.push(ch)
      }
    }
    return out.join("")
  })(repaired)
  if (_fixed !== repaired) {
    var _fixedParsed = jsonParse(_fixed, __, __, true)
    if (isMap(_fixedParsed) || isArray(_fixedParsed)) return _fixed
  }

  return jsonString
}

function __miniAExtractResponseTextCandidates(rawResponse) {
  var texts = []
  var addText = function(value) {
    if (isUnDef(value)) return
    if (isString(value)) {
      var cleaned = String(value)
      if (cleaned.trim().length > 0) texts.push(cleaned)
    }
  }
  var addFromParts = function(parts) {
    if (!isArray(parts)) return
    parts.forEach(function(part) {
      if (isString(part)) {
        addText(part)
      } else if (isMap(part)) {
        addText(part.text)
        addText(part.content)
      }
    })
  }

  if (isString(rawResponse)) addText(rawResponse)
  if (isMap(rawResponse)) {
    addText(rawResponse.response)
    addText(rawResponse.content)
    addText(rawResponse.completion)
    addText(rawResponse.text)
    addText(rawResponse.output)
    addText(rawResponse.output_text)
    addText(rawResponse.reasoning)
    addText(rawResponse.thinking)

    if (isMap(rawResponse.message)) {
      addText(rawResponse.message.content)
      addText(rawResponse.message.thinking)
      addText(rawResponse.message.reasoning)
      addFromParts(rawResponse.message.content)
    }
    addFromParts(rawResponse.content)

    if (isArray(rawResponse.choices)) {
      rawResponse.choices.forEach(function(choice) {
        if (isUnDef(choice)) return
        addText(choice.text)
        addText(choice.thinking)
        addText(choice.reasoning)
        if (isMap(choice.message)) {
          addText(choice.message.content)
          addText(choice.message.thinking)
          addText(choice.message.reasoning)
          addFromParts(choice.message.content)
        }
        if (isMap(choice.delta)) {
          addText(choice.delta.content)
          addText(choice.delta.thinking)
          addText(choice.delta.reasoning)
        }
        addFromParts(choice.content)
      })
    }

    if (isArray(rawResponse.candidates)) {
      rawResponse.candidates.forEach(function(candidate) {
        if (isUnDef(candidate)) return
        if (isMap(candidate.content)) {
          addText(candidate.content.text)
          addFromParts(candidate.content.parts)
        }
        addText(candidate.output)
        addText(candidate.text)
      })
    }

    if (isArray(rawResponse.messages)) {
      rawResponse.messages.forEach(function(message) {
        if (isUnDef(message)) return
        addText(message.content)
        addFromParts(message.content)
      })
    }
  }

  if (texts.length === 0 && isMap(rawResponse)) addText(stringify(rawResponse, __, ""))
  return texts
}

function __miniAExtractStructuredThinkingTexts(rawResponse) {
  var texts = []
  var addText = function(value) {
    if (isString(value) && value.trim().length > 0) texts.push(value)
  }
  var scanParts = function(parts) {
    if (!isArray(parts)) return
    parts.forEach(function(part) {
      if (!isMap(part)) return
      var t = String(part.type || "").toLowerCase()
      if (t === "thinking" || t === "reasoning") {
        addText(part.thinking)
        addText(part.text)
      }
    })
  }

  if (!isMap(rawResponse)) return texts
  addText(rawResponse.reasoning)
  addText(rawResponse.thinking)

  if (isMap(rawResponse.message)) {
    addText(rawResponse.message.thinking)
    addText(rawResponse.message.reasoning)
    scanParts(rawResponse.message.content)
  }

  scanParts(rawResponse.content)
  if (isArray(rawResponse.choices)) {
    rawResponse.choices.forEach(function(choice) {
      if (isUnDef(choice)) return
      addText(choice.thinking)
      addText(choice.reasoning)
      if (isMap(choice.message)) {
        addText(choice.message.thinking)
        addText(choice.message.reasoning)
        scanParts(choice.message.content)
      }
      if (isMap(choice.delta)) {
        addText(choice.delta.thinking)
        addText(choice.delta.reasoning)
      }
    })
  }

  return texts
}

function __miniAParseJsonCandidate(rawText, repairFn) {
  if (!isString(rawText)) return __
  var text = rawText.trim()
  if (text.length === 0) return __

  var parsed = jsonParse(text, __, __, true)
  if (isMap(parsed) || isArray(parsed)) return parsed

  var firstObj = text.indexOf("{")
  var lastObj = text.lastIndexOf("}")
  if (firstObj >= 0 && lastObj > firstObj) {
    var objCandidate = text.substring(firstObj, lastObj + 1)
    parsed = jsonParse(objCandidate, __, __, true)
    if (isMap(parsed) || isArray(parsed)) return parsed
  }

  var firstArr = text.indexOf("[")
  var lastArr = text.lastIndexOf("]")
  if (firstArr >= 0 && lastArr > firstArr) {
    var arrCandidate = text.substring(firstArr, lastArr + 1)
    parsed = jsonParse(arrCandidate, __, __, true)
    if (isMap(parsed) || isArray(parsed)) return parsed
  }

  var extractBalancedJson = function(source) {
    if (!isString(source)) return ""
    var trimmed = source.trim()
    if (trimmed.length === 0) return ""
    var start = -1
    var openCh = ""
    var closeCh = ""
    for (var i = 0; i < trimmed.length; i++) {
      var ch = trimmed.charAt(i)
      if (ch === "{") { start = i; openCh = "{"; closeCh = "}"; break }
      if (ch === "[") { start = i; openCh = "["; closeCh = "]"; break }
    }
    if (start < 0) return ""

    var depth = 0
    var inString = false
    var escaped = false
    for (var j = start; j < trimmed.length; j++) {
      var cur = trimmed.charAt(j)
      if (escaped) { escaped = false; continue }
      if (cur === "\\") { escaped = true; continue }
      if (cur === "\"") { inString = !inString; continue }
      if (inString) continue
      if (cur === openCh) depth++
      if (cur === closeCh) depth--
      if (depth === 0) return trimmed.substring(start, j + 1)
    }
    return ""
  }

  var balancedCandidate = extractBalancedJson(text)
  if (balancedCandidate.length > 0) {
    parsed = jsonParse(balancedCandidate, __, __, true)
    if (!(isMap(parsed) || isArray(parsed)) && isFunction(repairFn)) {
      var repairedBalanced = repairFn(balancedCandidate)
      if (repairedBalanced !== balancedCandidate) parsed = jsonParse(repairedBalanced, __, __, true)
    }
    if (isMap(parsed) || isArray(parsed)) return parsed
  }

  return __
}

function __miniAStripThinkingTagsFromString(text, allowedTags, tagNormalizer) {
  if (!isString(text)) return { cleaned: text, blocks: [] }
  var tagPattern = /<\s*([a-zA-Z0-9_-]+)(?:\s[^>]*)?>([\s\S]*?)<\/\s*\1\s*>/g
  var blocks = []
  var seen = {}
  var cleaned = text.replace(tagPattern, function(match, tag, content) {
    var normalized = isFunction(tagNormalizer) ? tagNormalizer(tag) : String(tag || "")
    if (!isMap(allowedTags) || allowedTags[normalized] !== true) return match
    var trimmed = (content || "").toString().trim()
    if (trimmed.length > 0 && !seen[trimmed]) { seen[trimmed] = true; blocks.push(trimmed) }
    return ""
  }).trim()
  return { cleaned: cleaned, blocks: blocks }
}

function __miniAExtractEmbeddedFinalAction(answerPayload, cleanCodeBlocksFn) {
  if (isUnDef(answerPayload)) return null
  var embedded = answerPayload
  if (isString(embedded)) {
    var cleaner = isFunction(cleanCodeBlocksFn) ? cleanCodeBlocksFn : __miniACleanCodeBlocks
    var cleaned = cleaner(embedded).trim()
    if (cleaned.length === 0) return null
    if (!cleaned.match(/^(\{|\[)/)) return null
    try {
      embedded = jsonParse(cleaned, __, __, true)
    } catch (e) {
      return null
    }
  }
  if (!isMap(embedded)) return null
  var embeddedActionRaw = ((embedded.action || embedded.type || embedded.name || embedded.tool || embedded.think || "") + "").trim()
  if (embeddedActionRaw.toLowerCase() !== "final") return null
  if (isUnDef(embedded.answer)) return null
  var hasEmbeddedThought = isDef(embedded.thought) || isDef(embedded.think)
  if (!hasEmbeddedThought) return null

  var normalized = { action: "final", answer: embedded.answer }
  if (isDef(embedded.thought)) normalized.thought = embedded.thought
  else if (isDef(embedded.think)) normalized.thought = embedded.think
  if (isDef(embedded.state)) normalized.state = embedded.state
  if (isDef(embedded.params)) normalized.params = embedded.params
  if (isDef(embedded.command)) normalized.command = embedded.command
  return normalized
}

function __miniAParseListOption(value) {
  if (isUnDef(value) || value === null) return []
  if (isArray(value)) {
    return value
      .map(function(v) { return (isString(v) ? v : stringify(v, __, "")).toLowerCase().trim() })
      .filter(function(v) { return v.length > 0 })
  }
  if (!isString(value)) value = stringify(value, __, "")
  return value.split(",").map(function(v) { return v.trim().toLowerCase() }).filter(function(v) { return v.length > 0 })
}

// Accept a channel definition or a native filesystem path. A path is converted
// to the file-channel shape expected by OpenAF while structured SLON/JSON is
// left untouched.
function __miniANormalizeChannelDef(value) {
  if (!isString(value)) return value
  var text = value.trim()
  if (text.length === 0) return value

  var parsed = __
  try { parsed = af.fromJSSLON(text) } catch(ignoreChannelDefParse) {}
  if (isMap(parsed) || isArray(parsed)) return value

  try {
    java.nio.file.Paths.get(text)
    if (io.fileExists(text) && io.fileInfo(text).isDirectory) return value
    return stringify({ type: "file", options: { file: text } }, __, "")
  } catch(ignoreInvalidChannelPath) {
    return value
  }
}

function __miniANormalizePromptProfile(profile, fallbackProfile) {
  var normalized = isString(profile) ? profile.trim().toLowerCase() : ""
  if (normalized === "minimal" || normalized === "balanced" || normalized === "verbose") return normalized
  return isString(fallbackProfile) && fallbackProfile.length > 0 ? fallbackProfile : "balanced"
}

function __miniAStemWord(word) {
  var suffixes = [
    { pattern: /ness$/, replacement: "" },
    { pattern: /ing$/, replacement: "" },
    { pattern: /ed$/, replacement: "" },
    { pattern: /es$/, replacement: "" },
    { pattern: /s$/, replacement: "" },
    { pattern: /ied$/, replacement: "y" },
    { pattern: /ies$/, replacement: "y" },
    { pattern: /ation$/, replacement: "ate" },
    { pattern: /tion$/, replacement: "t" },
    { pattern: /er$/, replacement: "" },
    { pattern: /ly$/, replacement: "" },
    { pattern: /able$/, replacement: "" },
    { pattern: /ible$/, replacement: "" }
  ]
  for (var i = 0; i < suffixes.length; i++) {
    if (suffixes[i].pattern.test(word) && word.length > 4) return word.replace(suffixes[i].pattern, suffixes[i].replacement)
  }
  return word
}

function __miniALevenshteinDistance(a, b) {
  if (a.length === 0) return b.length
  if (b.length === 0) return a.length
  var matrix = []
  for (var i = 0; i <= b.length; i++) matrix[i] = [i]
  for (var j = 0; j <= a.length; j++) matrix[0][j] = j
  for (i = 1; i <= b.length; i++) {
    for (j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) matrix[i][j] = matrix[i - 1][j - 1]
      else matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1)
    }
  }
  return matrix[b.length][a.length]
}
